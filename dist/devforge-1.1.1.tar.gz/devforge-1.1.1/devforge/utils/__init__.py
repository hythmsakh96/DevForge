# Utility functions (reserved for future features)
